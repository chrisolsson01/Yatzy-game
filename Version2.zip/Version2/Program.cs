﻿using System;

namespace Version2
{
    class Program
    {
        static void Main(string[] args)
        {
            Start starta = new Start();
            starta.Game();

        }

        
    }
}
